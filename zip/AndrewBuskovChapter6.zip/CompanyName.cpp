/*
 * Program: CompanyName.cpp
 * Programmer: Andrew Buskov
 * Class: CIT 142
 * Date: Nov 1, 2013
 */
#include <iostream>
using namespace std;

void companyName(){
	cout << "C++ Software Developers";;
}



