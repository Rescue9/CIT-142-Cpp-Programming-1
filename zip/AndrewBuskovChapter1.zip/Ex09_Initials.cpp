/*
 * Program: Initials.cpp
 * Programmer: Andrew Buskov
 * Class: CIT 142
 * Date: Aug 22, 2013
 */

/* Purpose: To create my initials 5 lines high, using my initials */

#include <iostream>
using namespace std;

int main(){
	// no classes this time.. just simple output
	cout << "    A       BBBBB  \n";
	cout << "   A A      B    B \n";
	cout << "  AAAAA     BBBBB  \n";
	cout << " A     A    B    BB\n";
	cout << "A       A   BBBBB  \n";

	return 0;
}
